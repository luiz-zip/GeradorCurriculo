<?php
// Recebendo dados do formulário
$nome = $_POST['nome'];
$dataNascimento = $_POST['dataNascimento'];
$idade = $_POST['idade'];
$descricao = $_POST['descricao'];
// Processar outros campos conforme necessário

// Gerar o currículo em HTML
$curriculo = "
<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <title>Currículo de $nome</title>
    <link rel='stylesheet' href='css/bootstrap.min.css'>
    <link rel='stylesheet' href='css/styles.css'> <!-- Seu arquivo CSS personalizado -->
</head>
<body>
    <div class='container mt-5'>
        <h1>Currículo de $nome</h1>
        <p><strong>Nome:</strong> $nome</p>
        <p><strong>Data de Nascimento:</strong> $dataNascimento</p>
        <p><strong>Idade:</strong> $idade anos</p>
        <!-- Adicionar mais informações conforme necessário -->
        <button onclick='window.print();' class='btn btn-success'>Baixar Currículo</button>
    </div>
</body>
</html>
";

// Exibir o currículo
echo $curriculo;
?>
